var express = require('express');
var urlencodedParser = require('urlencoded-parser');
const bodyParser = require('body-parser');
var alert = require('alert');
const e = require('express');
const app = express();
const res = require('express/lib/response');
const { urlencoded } = require('body-parser');

app.use(express.urlencoded({extended:false}));

app.use(express.static(__dirname + "Page.html"));
app.use(express.static(__dirname + "User.html"));
app.use(express.static(__dirname + "Input.html"));

app.get('/', function (req, res) 
{
    res.sendFile('Page.html', { root: __dirname })
});

app.get('/admin',urlencodedParser, function (req, res) {
    res.sendFile(__dirname + "/Input.html");
});

var name,ssn;

app.post('/Sub',async function (req, res) 
{
    name = req.body.username;
    ssn = req.body.usn;

    console.log(name,ssn);
    if(name!="" || ssn!="")
    {
        senddata();
        getdata();
    }
    else
    {
        alert('All Fields are Mandatory');
    }

});

app.listen(8080, function (req, res) 
{
    console.log("Running..")
});


var accaddress = '0x178FA621dE8f150Bb8c12E421DB7145C4AA94D87';
var contractadd = '0x1e51FEf435355354b92cF0d89Ac3B7716B63A73c';

var abi = [
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "_name",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_pssd",
				"type": "string"
			}
		],
		"name": "Setdetails",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "Getdetails",
		"outputs": [
			{
				"internalType": "string[]",
				"name": "",
				"type": "string[]"
			},
			{
				"internalType": "string[]",
				"name": "",
				"type": "string[]"
			}
		],
		"stateMutability": "view",
		"type": "function"
	}
]

var username =[];
var password=[];
async function senddata()
{
    const Web3 = require('web3');
    var web3 = new Web3('http://localhost:8545')
    //web3.personal.unlockAccount(web3.personal.listAccounts[0], null, 600000)


    var MyContract = new web3.eth.Contract(abi, contractadd);
    await MyContract.methods.Setdetails(name, ssn).send({ from: accaddress })
    .then(console.log)
}
var i=0;
async function getdata()
{
    const Web3 = require('web3');
    var web3 = new Web3('http://localhost:8545')
    //web3.personal.unlockAccount(web3.personal.listAccounts[0], null, 600000)


    var MyContract = new web3.eth.Contract(abi, contractadd);
    await MyContract.methods.Getdetails().call({ from: accaddress }, function (err, results) {
        if (err) throw err;
        var size = results[0].length;
        console.log("array size = ",size);

        for(i=0; i<=size; i++)
        {
            username[i] = results[0][i];
            password[i] = results[1][i];

            console.log("Username is "+ username[i]+" USn is "+password[i]);
        }
});
}